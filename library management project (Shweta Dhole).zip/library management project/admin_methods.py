from admin import Book
from datetime import datetime
class Admin_methods:
    def AddBook(self,b):
        with open("book.txt","a") as fp:
            fp.write(str(b)+"\n")
    
    def DeleteBookbyId(self,id):
        AllBook=[]
        found=False
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                    except:
                        AllBook.append(line)
                    else:
                        found=True
                    
            if(found):
                with open("book.txt","w") as fp:
                    for b in AllBook:
                        fp.write(b)
            else:
                print("record not found")

        except:
            print("file is not present")
            return

    def EditBookbyId(self,id):
        AllBook=[]
        found=False
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                
                    except:
                        pass
                    else:
                        found=True
                        line=line.split(",")
                        print(line)
                        ans=input("Do you wish to chaange name(y/n): ")
                        if(ans.lower()=="y"):
                            line[1]=(input("Enter new book name: "))
                        ans=input("Do you wish to change book author(y/n): ")
                        if(ans.lower()=="y"):
                            line[2]=(input("Enter new book author: "))
                        ans=input("Do you want to change book status: ")
                        if(ans.lower()=="y"):
                            line[3]=(input("Enter book status: "))
                            line[3]+="\n"
                            print(line)
                        line=",".join(line)
                    AllBook.append(line)
            if(found):
                with open("book.txt","w") as fp:
                    for b1 in AllBook:
                        fp.write(b1)
            else:
                print("record not found")

        except:
            print("file is not present")
            return
    
    def SearchBookbyId(self,id):
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                        print("Found: ",line)
                        break
                    except:
                        pass
                else:
                    print("record not found")
               
        except:
            print("file does not exist")

    def SearchBookbyName(self,name):
        try:
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        (line.lower()).index(name.lower())
                        print("Found: ",line)
                        break
                    except:
                        pass
                else:
                    print("record not found")

        except:
            print("file does not exist")

    def ShowBook(self):
        try:
            with open("book.txt","r") as fp:
                print(fp.read())

        except:
            print("record not found")

    def Issue_Book(self,u,id):
        try:
            allBook=[]
            found=False
            with open("book.txt","r")as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                        print("found: ",line)
                        line=line.strip()
                        line=line.split(",")
                        found=True
                        if(int(line[3])==1):
                            with open("issue.txt","a") as fpp:
                                fpp.write(str(u)+"\n")
                        else:
                            print("book is not available")
                            return
                        line[3]="0\n"
                        line=",".join(line)
                    except:
                        pass
                    finally:
                        allBook.append(line)
            print(allBook)
            if(found):
                with open("book.txt","w") as fp:
                    for book in allBook:
                        fp.write(book)
            else:
                print("record not found")

        except:
            print("file does not exist")

    def Submit_Book(self,id1):
        try:
            submitbook=[]
            found=False
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id1),0,4)
                        print("Found: ",line)
                        line=line.strip()
                        line=line.split(",")
                        found=True
                        line[3]="1\n"
                        line=",".join(line)
                    except:
                        pass
                    finally:
                        submitbook.append(line)
            print(submitbook)
            if(found):
                with open("book.txt","w") as fp:
                    for s in submitbook:
                        fp.write(s)
            else:
                print("record not found")

        except:
            print("file does not exist")
    
    def Calculate_fine(self,id1,submit_date):
            with open("issue.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id1),0,4)
                        line=line.split(",")
                        issue_date=line[1]
                        issue_date=issue_date.split("-")
                        day=int(issue_date[0])
                        month=int(issue_date[1])
                        year=int(issue_date[2])
                        issue_date=datetime(year,month,day)

                        submit_date=submit_date.split("-")
                        day=int(submit_date[0])
                        month=int(submit_date[1])
                        year=int(submit_date[2])
                        submit_date=datetime(year,month,day)
                        days=(submit_date-issue_date).days
                        if(days>6):
                            fine_per_day=30
                            extra_days=days-6
                            fine=extra_days*fine_per_day
                            print("you have taken extra days pay fine: ",fine)
                        else:
                            print("Thank you")
                    except:
                        pass
                        
    def Delete_book(self,id1):
        book=[]
        found=False
        try:
            with open("issue.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id1),0,4)
                        #print("Found: ",line)
                    except:
                        book.append(line)
                    else:
                        found=True
                    
            if(found):
                with open ("issue.txt","w") as fp:
                    for iss in book:
                        fp.write(iss)
            else:
                print("record not found")

        except:
            print("file does not exist")
            return

        