from user import user
from admin_methods import Admin_methods
from admin import Book
def User():
    usermgmt=Admin_methods()
    ch=0
    while(ch!=6):
        print('''
        \t\t1.Search Book
        \t\t2.Show AllBook
        \t\t3.Issue Book
        \t\t4.Submit Book
        \t\t5.Exit
        ''')
        ch=int(input("Enter your choice: "))
        if(ch==1):
            print("a.Do you want to search book by Id: ")
            print("b.Do you want to search book by name: ")
            ans=(input("Enter your choice: "))
            if(ans=="a"):
                id=int(input("Enter id you want to serch: "))
                usermgmt.SearchBookbyId(id)
            elif(ans=="b"):
                name=input("Enter the book name you want to search: ")
                usermgmt.SearchBookbyName(name)
            else:
                print("invalid choice")
        elif(ch==2):
            usermgmt.ShowBook()
        elif(ch==3):
            id=int(input("Enter book id you want to issue: "))
            date=(input("Enter isssue date(dd-mm-yyyy) format: "))
            name=input("Enter name of user: ")
            u=user(id,date,name)
            usermgmt.Issue_Book(u,id)
        elif(ch==4):
            id1=int(input("Enter id of book you want to submit: "))
            submit_date=(input("Enter submit date(dd-mm-yyyy) format: "))
            usermgmt.Submit_Book(id1)
            usermgmt.Calculate_fine(id1,submit_date)
            usermgmt.Delete_book(id1)
        elif(ch==5):
            print("Exit")
        else:
            print("invalid choice")