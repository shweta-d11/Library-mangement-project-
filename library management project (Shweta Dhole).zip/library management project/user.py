class user:
    def __init__(self,id,date,name):
        self.id=id
        self.issuedate=date
        self.name=name

    def __str__(self):
        return str(self.id)+","+str(self.issuedate)+","+(self.name)