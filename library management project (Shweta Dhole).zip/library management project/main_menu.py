from admin_main import Admin
from user_main import User
ch=0
if(__name__=="__main__"):
    print('''
    1.Admin Section
    2.User section
    ''')
    ch=int(input("Enter your choice: "))
    if(ch==1):
        user_nm=input("Enter User name: ")
        paswrd=input("Enter password: ")
        if(user_nm=="vaishali" and paswrd=="ABC11"):
            Admin()
        else:
            print("wrong username or password")
    elif(ch==2):
        User()
    else:
        print("invalid choice: ")