from admin import Book
from admin_methods import Admin_methods
def Admin():
    choice=0
    adminmgmt=Admin_methods()
    while(choice!=6):
        print('''
        \t\t1.Add Book
        \t\t2.Delete Book
        \t\t3.Edit Book
        \t\t4.Search Book
        \t\t5.Showall Book
        \t\t6.Exit
          ''')
        choice=int(input("Enter your choice: "))
        if(choice==1):
            bid=int(input("Enter Book id: "))
            bname=input("Enter book name: ")
            bauthor=input("Enter book author name: ")
            status=int(input("Enter status of abook: "))
            b1=Book(bid,bname,bauthor,status)
            adminmgmt.AddBook(b1)
        elif(choice==2):
            id=int(input("Enter the id of book you want to delete: "))
            adminmgmt.DeleteBookbyId(id)
        elif(choice==3):
            id=int(input("Enter id of book you want to edit: "))
            adminmgmt.EditBookbyId(id)
        elif(choice==4):
            print("\ta.search book by id")
            print("\tb. search book by name")
            ch=(input("enter your choice(a/b): "))
            if(ch.lower()=="a"):
                id=int(input("Enter book id you want to search: "))
                adminmgmt.SearchBookbyId(id)
            elif(ch.lower()=="b"):
                name=input("Enter book name you want to search: ")
                adminmgmt.SearchBookbyName(name)
            else:
                print("invalid choice")
        elif(choice==5):
            adminmgmt.ShowBook()
        elif(choice==6):
           print("exit")
        else:
           print("invalid input")
